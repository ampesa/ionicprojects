import { Component } from '@angular/core';
import { NavParams, ViewController } from 'ionic-angular';

/**
 * Generated class for the AdultUserComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'adult-user',
  templateUrl: 'adult-user.html'
})

export class AdultUserComponent {

  userName: string;

  constructor( public navParams: NavParams, public viewCtrl: ViewController ) {

  }

  ionViewDidEnter(){
    this.userName = this.navParams.get('userName');
  }

  goToEvents(){
    this.viewCtrl.dismiss({result: "goToEvents"});
    console.log("your selection is go to Events");
  }

  backToLogin(){
    this.viewCtrl.dismiss({result: "backToLogin"});
    console.log("your selection is back to Login");
  }

}
