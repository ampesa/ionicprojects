export function getPath(team){
    return '../../assets/imgs/'+team+'.png';
  }