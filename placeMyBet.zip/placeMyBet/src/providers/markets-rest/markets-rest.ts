import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the MarketsRestProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class MarketsRestProvider {
  
  baseUrl : string = "http://localhost:53454/api/Markets/";

  constructor(public http: HttpClient) {
    
  }

  getMarketsData(id){
    return this.http.get(this.baseUrl + id + "/");
  }


  putMarketBet(bet){

    this.http.put(this.baseUrl, bet, {
      headers: {
        responseType: "json"
      }}).subscribe();
  }

}
